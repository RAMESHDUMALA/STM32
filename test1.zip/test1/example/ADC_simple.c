/**
  ***************************************************************************** 
  * @title   ADC_simple.c
  * @author  Claude
  * @date    2010 Dec 29
  * @brief   ADC Example, Blink a LED according to ADC value
  *******************************************************************************
  */

#include<stm32f10x_rcc.h>
#include<stm32f10x_gpio.h>
#include<stm32f10x_adc.h>

#include "stm32f10x.h"
#include "stm32f10x_conf.h"

GPIO_InitTypeDef GPIO_InitStructure;
ADC_InitTypeDef ADC_InitStructure;
int i,j;

/* Blink a LED, blink speed is set by ADC value */
void ADC_simple(void)
{
// init for GPIO (LED)
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9 ;	// two LED (guess on what pin!!)
	GPIO_Init(GPIOB, &GPIO_InitStructure);

// input of ADC (it doesn't seem to be needed, as default GPIO state is floating input)
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_1 ;		// that's ADC1 (PA1 on STM32)
	GPIO_Init(GPIOA, &GPIO_InitStructure);

//clock for ADC (max 14MHz --> 72/6=12MHz)
	RCC_ADCCLKConfig (RCC_PCLK2_Div6);
// enable ADC system clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

// define ADC config
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;	// we work in continuous sampling mode
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 1;

	ADC_RegularChannelConfig(ADC1,ADC_Channel_1, 1,ADC_SampleTime_28Cycles5); // define regular conversion config
	ADC_Init ( ADC1, &ADC_InitStructure);	//set config of ADC1

// enable ADC
	ADC_Cmd (ADC1,ENABLE);	//enable ADC1

//	ADC calibration (optional, but recommended at power on)
	ADC_ResetCalibration(ADC1);	// Reset previous calibration
	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);	// Start new calibration (ADC must be off at that time)
	while(ADC_GetCalibrationStatus(ADC1));

// start conversion
	ADC_Cmd (ADC1,ENABLE);	//enable ADC1
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);	// start conversion (will be endless as we are in continuous mode)

// debug information
	RCC_ClocksTypeDef forTestOnly;
	RCC_GetClocksFreq(&forTestOnly);	//this could be used with debug to check to real speed of ADC clock

	j= 50000;
    while(1)
    {
    	GPIO_WriteBit(GPIOB,GPIO_Pin_8,Bit_RESET);
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,Bit_SET);
		for (i=0;i<j;i++);
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,Bit_RESET);
		GPIO_WriteBit(GPIOB,GPIO_Pin_8,Bit_SET);

		// adc is in free run, and we get the value asynchronously, this is not a really nice way of doing, but it work!
		j = ADC_GetConversionValue(ADC1) * 1000 ; // value from 0 to 4095000
		for (i=0;i<j;i++);
    }
    /* possible change :
     * ADC_ContinuousConvMode = DISABLE
     * then on the infinite loop, something like :
     *
     *  ADC_SoftwareStartConvCmd(ADC1, ENABLE);					// start ONE conversion
     *  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);	// wait end of conversion
     *  j = ADC_GetConversionValue(ADC1) * 500;					// get value
     *
     */
}