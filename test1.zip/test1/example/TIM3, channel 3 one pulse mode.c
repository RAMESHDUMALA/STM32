void tim3ch3onePulse()
{
	
	/*Please set RCC before to 24mhz (or calculate new prescalers for your
	 * desired values)
	 * */
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	//set clock to TIM3
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

		//enable port B and alternate function
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB |RCC_APB2Periph_AFIO,ENABLE);

		GPIO_InitTypeDef GPIO_InitStructure;

		//init port B pin 0 = TIM3 channel 3 to alternate function push-pull

		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
			GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;
			GPIO_Init(GPIOB, &GPIO_InitStructure);

			//timer basestructure 24mhz/(0+1)/(0+1) ~ 2,72mS (655353/24000000)s for full period
		 TIM_TimeBaseStructure.TIM_Prescaler = 0 ;
		TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
		 TIM_TimeBaseStructure.TIM_Period = 65535 ;
		TIM_TimeBaseStructure.TIM_ClockDivision = 0;
		 TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);


		 /* TIM3 PWM2 Mode configuration: Channel1 */
		 //for one pulse mode set PWM2, output enable, pulse (1/(t_wanted=TIM_period-TIM_Pulse)), set polarity high
		   TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
		   TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
		   TIM_OCInitStructure.TIM_Pulse = 48000;
		   TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

		   TIM_OC3Init(TIM3, &TIM_OCInitStructure);

		   TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

		   /* OPM Bit -> Only one pulse */
		   TIM3->CR1 |= (1 << 3);
		   /* TIM3 enable counter */
		   TIM_Cmd(TIM3, ENABLE);


	
}