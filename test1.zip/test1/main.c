void Tim2toTrigTim3Ch3OPM(void);
void tim3ch3onePulse();
void TIM_PWMOutput(void);

int main(void)
{

    //automatically added by CoIDE
	TIM_PWMOutput();

	//automatically added by CoIDE
	tim3ch3onePulse();

	//automatically added by CoIDE
	Tim2toTrigTim3Ch3OPM();

	while(1)
    {
    }
}

